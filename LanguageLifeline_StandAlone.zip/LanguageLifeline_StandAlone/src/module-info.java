/**
 * 
 */
/**
 * @author Babyshaq
 *
 */
module LanguageLifeline_StandAlone {
	requires java.desktop;
}