package standAlone;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;

import javax.imageio.ImageIO;

public class Server {
	
	public String language;
	public String phrase;
	public File audio;
	public File image;
	
	
	
	public void recieveInfo(String lang, String phrase, File image, File audio) {
		this.audio = audio;
		this.language = lang;
		this.phrase = phrase;
		this.image = image;
	}
	
	
	
	public void startServer() {
		ServerSocket server = null;
		  
        try {
  
            // server is listening on port 1234
            server = new ServerSocket(4200);
            server.setReuseAddress(true);
  
            // running infinite loop for getting
            // client request
            while (true) {
  
                // socket object to receive incoming client
                // requests
                Socket client = server.accept();
  
                // Displaying that new client is connected
                // to server
                System.out.println("New client connected"
                                   + client.getInetAddress()
                                         .getHostAddress());
  
                try {
                	ClientHandler clientSock = new ClientHandler(client, language, phrase, image, audio);
                	new Thread(clientSock).start();
                } catch (Exception e) {
                	ClientHandler clientSock = new ClientHandler(client);
                	new Thread(clientSock).start();
                }
                
                
                // create a new thread object
             //   ClientHandler clientSock
              //      = new ClientHandler(client);
  
                // This thread will handle the client
                // separately
            //    new Thread(clientSock).start();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            if (server != null) {
                try {
                    server.close();
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
  
    // ClientHandler class
    private static class ClientHandler implements Runnable {
        private final Socket clientSocket;
        private final String language;
        private final String phrase;
        private final File image;
        private final File audio;
  
        // Constructor
        public ClientHandler(Socket socket)
        {
            this.clientSocket = socket;
            image = null;
            audio = null;
            language = "";
            phrase = "";
        }
  
        public ClientHandler(Socket socket, String Lang,  String phrase, File image, File audio) {
        	this.language =Lang;
        	this.phrase = phrase;
        	this.image = image;
        	this.audio = audio;
        	this.clientSocket = socket;
        }
        
        public void run()
        {
            PrintWriter out = null;
            BufferedReader in = null;
            try {
                    
                  // get the outputstream of client
                out = new PrintWriter(
                    clientSocket.getOutputStream(), true);
                
                OutputStream outputStream = clientSocket.getOutputStream();
                out.write("Language\n");
                out.flush();
                out.write(language + "\n");
                System.out.println(language);
                out.flush();
                out.write("Phrase\n");
                out.flush();
                out.write(phrase + "\n");
                out.flush();
                out.write("Image\n");
                out.flush();
               
                
                //Send an image through the socket connection
                BufferedImage bufImage = ImageIO.read(image);
                
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                
                ImageIO.write(bufImage, "jpg", byteArrayOutputStream);
                byte[] size = ByteBuffer.allocate(4).putInt(byteArrayOutputStream.size()).array();
                System.out.println(size.length);
                outputStream.write(size);
                outputStream.flush();
                System.out.println(byteArrayOutputStream.toByteArray().length);
                outputStream.write(byteArrayOutputStream.toByteArray());
                outputStream.flush();
                try {
					Thread.sleep(1200);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
             //   clientSocket.close();
                
                out.write("Audio\n");
                out.flush();
                
                //Send audio through the socket connection
                BufferedInputStream bis = new BufferedInputStream(new FileInputStream(audio));
                
                double nosofpackets=Math.ceil(((int) audio.length())/1024);
                
                for(int i =0; i<=nosofpackets; i++) {
                	byte[] mybytearray = new byte[1024];   
                    bis.read(mybytearray, 0, mybytearray.length);
                    outputStream.write(mybytearray);
                    outputStream.flush();
                }

                out.write("exit\n");
                
                
                
                
 
                /*// get the inputstream of client
                in = new BufferedReader(
                    new InputStreamReader(
                        clientSocket.getInputStream())); //This is where we can change the message being sent to whatever the user inputs to the GUI
  //https://www.codegrepper.com/code-examples/java/java+send+an+image+over+a+socket */
                
                
                
                
                String line;
          /*      while ((line = in.readLine()) != null) {
  
                    // writing the received message from
                    // client
                    System.out.printf(
                        " Sent from the client: %s\n",
                        line);
                    out.println(line);
                } */
            }
            catch (IOException e) {
                e.printStackTrace();
            }
            finally {
                try {
                    if (out != null) {
                        out.close();
                    }
                    if (in != null) {
                        in.close();
                        clientSocket.close();
                    }
                }
                catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
	}
