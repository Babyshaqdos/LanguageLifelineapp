package standAlone;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Server server = new Server();
		GUI gui = new GUI();
		
		
		
		gui.createGUI(server);
		
				
	//	server.startServer();
		
		

	}

}
