package standAlone;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class GUI {

	File imageFile;
	File audioFile;
	String Langinput;
	String phraseinput;
	
	
	public void createGUI(Server server) {
		//Create a JFrame element, this is the actual window that will pop up when the program is ran
		JFrame frame = new JFrame();
		
		
		//Create a button element
		
		//We can also change the size of the window that pops up for the user
		frame.setSize(800, 900);
		final JFileChooser audio_chooser = new JFileChooser();//Opens files
		final JFileChooser image_chooser = new JFileChooser();//opens files
		
		JLabel language = new JLabel(); //adds label for "enter language" 
		language.setText("<html>"+"<B>"+"Enter Language:"+"<html>"); //Adds text and makes it bold
		language.setBounds(250, 165, 300, 50);
		frame.add(language);
		
		JTextField languagetxtfield = new JTextField(""); //adds text field for user to enter language
		languagetxtfield.setBounds(250, 200, 300, 50);
		frame.add(languagetxtfield);
		
		JLabel phrase = new JLabel(); //adds "enter phrase" label
		phrase.setText("<html>"+"<B>"+"Enter Phrase:"+"<html>");//Adds text and makes it bold
		phrase.setBounds(250, 265, 300, 50);
		frame.add(phrase);
		
		JTextField phrasetxtfield = new JTextField(""); //adds text field for user to enter language
		phrasetxtfield.setBounds(250, 300, 300, 50);
		frame.add(phrasetxtfield);
		
		JButton audiobutton = new JButton("Upload Audio");//adds button to upload audio
		audiobutton.setBounds(250, 400, 140, 50); 
		audiobutton.addActionListener(new ActionListener() { //Makes it a button you can click on
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				audio_chooser.showOpenDialog(frame);
				audioFile = audio_chooser.getSelectedFile();
				//System.out.println(audioFile.getAbsolutePath());
			} 
		});
		//Make the color of the audio button Blue with White Text
		audiobutton.setBackground(Color.decode("#184E77")); //Makes the Button Blue
		audiobutton.setForeground(Color.WHITE); //Makes the text White
		audiobutton.setBorderPainted(false);
		audiobutton.setOpaque(true);
		frame.add(audiobutton);
		
		JButton imagebutton = new JButton("Upload Image");//adds button to upload image
		imagebutton.setBounds(250 + 160, 400, 140, 50); 
		imagebutton.addActionListener(new ActionListener() { //makes it a button you can click on
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				image_chooser.showOpenDialog(frame);
				// add stuff for listeners to handle the data 
				imageFile = image_chooser.getSelectedFile();
				//System.out.println(imageFile.getAbsolutePath());
			} 
		});
		imagebutton.setBackground(Color.decode("#184E77")); //Makes the Button Blue
		imagebutton.setForeground(Color.WHITE); //Makes the text White
		imagebutton.setBorderPainted(false);
		imagebutton.setOpaque(true);
		frame.add(imagebutton);
		
		JButton donebutton = new JButton("Done"); //adds button to submit information
		donebutton.setBounds(250, 500, 300, 50); 
		donebutton.setBackground(Color.decode("#184E77")); //Makes the Button Blue
		donebutton.setForeground(Color.WHITE); //Makes the text White
		donebutton.setBorderPainted(false);
		donebutton.setOpaque(true);
		donebutton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Langinput = languagetxtfield.getText();
				phraseinput = phrasetxtfield.getText();
				server.recieveInfo(Langinput, phraseinput, imageFile, audioFile);
				server.startServer();
				
			}
		});
		frame.add(donebutton);
		
		

		
		//We will also need a layout, there are multiple types of layouts you may choose from. Site below is a good resource
		//https://www.javatpoint.com/java-layout-manager#:~:text=The%20BorderLayout%20is%20used%20to,of%20a%20frame%20or%20window.
		//The default layout is border layout, it arranges the frame into 5 regions N, S, E, W, and center
		//We can set the frame to have no layout instead if we want to use the setBounds method (or using a layout might be easier, your choice)
		frame.setLayout(null);
		
		
		//Set the frame to visible so its displayed to the user
		frame.setVisible(true);
	}
	
}
